//
//  File.swift
//  Informed
//
//  Created by Katie Kroik on 4/15/16.
//  Copyright © 2016 nyu.edu. All rights reserved.
//

import Foundation
